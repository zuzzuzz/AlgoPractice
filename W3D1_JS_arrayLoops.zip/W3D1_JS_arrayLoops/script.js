

// function alwaysHungry(arr) { 
//     var checkArray = 0; 
//     for(var i=0; i<arr.length; i++){
//         if(arr[i] == "food") {
//             console.log("yummy");
//             checkArray++; 
//         }
//     }
//     if(checkArray == 0) {
//         console.log("I'm hungry" )
//     }
// }

// alwaysHungry([3.14, "food", "pie", true, "food"]);
// alwaysHungry([4, 1, 5, 7, 2]); 



// function highPass(arr, cutoff) {
//     var filteredArr = [];
//     for (var i=0; i<arr.length; i++) {
//         if(arr[i] > cutoff) {
//             filteredArr.push(arr[i]); 
//         }
//     }
//     return filteredArr;
// }

// var result = highPass([6, 8, 3, 10, -2, 5, 9], 5);
// console.log(result); 


// function betterThanAverage(arr) {
//     var sum = 0;
//     for(var i=0; i<arr.length; i++) {
//         sum += arr[i];
//     }

//     var avg = sum / arr.length;
//     var count = 0

//     for(var i=0; i<arr.length; i++) {
//         if(arr[i] > avg) {
//             count++;
//         }
//     }
//     return count;
// }
// var result = betterThanAverage([6, 8, 3, 10, -2, 5, 9]);
// console.log(result); 



// Write a function that will reverse the values an array and return them.


// var words = (["a", "b", "c", "d", "e"]);
// console.log (words.reverse())
// solution 1


// let array = (["a", "b", "c", "d", "e"]);
// let reverseArray = []; 
//     for (let i= array.length; i > 0; i-- ){
//         reverseArray.push(array[i-1]); 
//     }

// console.log(reverseArray);
// solution 2 


// var results = (["a", "b", "c", "d", "e"]);

// function reverseArray(array) {
//     var ret = []; 
//     for (let i= array.length-1; i>= 0; i-- ){
//         ret.push(array[i])
//     }
//     return ret; 
//     }
//     var reverseArrayData = reverseArray(["a", "b", "c", "d", "e"]); 

// console.log(reverseArrayData); 
// solution 3 


// var results= (["a", "b", "c", "d", "e"]);

// function reverse(arr){
//     var start, end; 
//     var j = arr.length-1; 

//     for(var i=0; i<j; i++) {
//         start = arr[i]; 
//         end = arr[j]; 
//         arr[i] = end; 
//         arr[j] = start; 
//         j = j-1;  i
//     }

//     return arr; 
// }
// console.log(reverse(results)); 
// solution 4

