//Print odds 1-20

for (var i=1; i<=20; i++) {
    if (i % 2 === 1) {
        console.log(i); 
    } 
}

// Decreasing Multiples of 3 : console.log values divisible by 3 from 100 -->0 

for (var i = 100; i> 0; i--) {
    if (i % 3 === 0)
     console.log(i); 
}

// Print the sequence : console.log values in the sequsen 4, 2.5, 1, -0.5, -2, -3.5

// Answer 1
let arr = [4, 2.5, 1, -0.5, -2, -3.5]; 

    let sum = arr.reduce(function (a, b) {
        return a + b; 
    }, 0 ); 
    console.log(sum); 

// // // answer 2

// var array = [4, 2.5, 1, -0.5, -2, -3.5]; 
// let num = 0; 
// for (let e of array) {
//     num += e; 
// }
// console.log(num)

// // answer 3

// function sumOfAll (arr) {
//     return arr.reduce((acc,curr) =>
//         acc + curr); 
// }; 
// console.log(sumOfAll ([4, 2.5, 1, -0.5, -2, -3.5])) 


// Sigma : console.log the sum of all numbers 1-100
function sumTo(n) {
    let sum = 0;
    for (let i = 1; i <= n; i++) {
    sum +=i;
    }
    return sum;
}

console.log( sumTo(100));

// answer 2 
// var sum = 0;

// for (var i = 1; i<=100; i++) {
//     sum += i; 
// }
// console.log(sum); 


// Factorial: console.log the product total of all values 1-12 
var array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];  
console.log(array.reduce((a,b) => a*b)
)

// answer 2

// var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]; 

// var multiply = (arr) => {
//     var product = 1; 
//     for (i = 0; i < arr.length; i++)
//     product = product * arr[i]; 
//     return product; 
// }
// console.log(multiply(arr)); 

